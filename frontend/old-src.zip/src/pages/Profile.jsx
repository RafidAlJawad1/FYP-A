function Profile() {
    return (
      <div>
        <h2>Profile</h2>
        <div className="profile-section">
          <div className="profile-picture">👤</div>
        </div>
      </div>
    );
  }
  
  export default Profile;  