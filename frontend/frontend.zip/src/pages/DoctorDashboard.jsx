function DoctorDashboard() {
    return (
        <div>
            <h2>Doctor Dashboard</h2>
            <p>Welcome to the doctor portal.</p>
        </div>
    );
}

export default DoctorDashboard;
