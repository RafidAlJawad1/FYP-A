import './patient.css';


function Chatbot() {
    return (
        <div style={{
            border: '2px dashed gray',
            height: '29%',
            width: '30%',
            padding: '20rem',
            backgroundColor: '#fffaf0'
        }}>
            <h3>Chatbot (Coming Soon)</h3>
            <p>This area will host the chatbot interface.</p>
        </div>
    );
}

export default Chatbot;
