function PatientDashboard() {
  return (
    <div>
      <h2>Patient Dashboard</h2>
      <p>Welcome to the patient portal.</p>
    </div>
  );
}

export default PatientDashboard;
